import gtcacheai

gtcacheai.main(['CACHE_SRC=rnd.c', 'CACHE_FLAGS=-DRND_REPLACEMENT'])

