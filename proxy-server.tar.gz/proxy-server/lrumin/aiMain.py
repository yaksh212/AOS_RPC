import gtcacheai

gtcacheai.main(['CACHE_SRC=lrumin.c', 'CACHE_FLAGS=-DLRUMIN_REPLACEMENT'])

