import gtcacheai

gtcacheai.main(['CACHE_SRC=lru.c', 'CACHE_FLAGS=-DLRU_REPLACEMENT'])
