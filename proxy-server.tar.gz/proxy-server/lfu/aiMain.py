import gtcacheai

gtcacheai.main(['CACHE_SRC=lfu.c', 'CACHE_FLAGS=-DLFU_REPLACEMENT'])
