print "No tests are provided for this assignment.  Test your program on your own platform."
