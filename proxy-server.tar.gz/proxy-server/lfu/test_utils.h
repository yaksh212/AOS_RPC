#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#define UDACIOUS_EXIT 59

#endif
