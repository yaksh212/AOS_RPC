print "Unfortunately, we can't let you use our servers to crawl the web.  On the bright side, this code is easy to test on your own platform."
